package com.firstprayer.rmi_tutorial;

import java.net.MalformedURLException;
import java.rmi.AlreadyBoundException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;

public class RMIServer {
	
	public static int REGISTRY_PORT = 17283;
	public static String REGISTRY_HOST = "127.0.0.1";
	
	public static void main(String[] args) throws RemoteException, MalformedURLException, AlreadyBoundException{
		// Create the registry server
		LocateRegistry.createRegistry(REGISTRY_PORT);
		
		// Initialize the class instance we want to bind
		QueueOperate operator = new QueueOperateImpl();
		
		// Bind the class instance to the registry server
		String bindingName = "queueOperate";
		String bindingUrl = String.format("//%s:%d/%s", 
				REGISTRY_HOST, REGISTRY_PORT, bindingName);
		Naming.bind(bindingUrl, operator);
		
		
	}
}
