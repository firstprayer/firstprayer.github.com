package com.firstprayer.rmi_tutorial;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface QueueOperate extends Remote {
	
	public void put(QueueItem item) throws RemoteException;
	public QueueItem poll() throws RemoteException;
	public int size() throws RemoteException;
	
}
