package com.firstprayer.rmi_tutorial;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.Random;

public class Client {
	
	static class ClientThread extends Thread{
		
		int id;
		public ClientThread(int i) {
			id = i;
		}
		
		private void log(String msg){
			System.out.println("[Client " + id + "]" + msg);
		}
		
		@Override
		public void run(){
			String bindingName = "queueOperate";
			String lookUpUrl = String.format("//%s:%d/%s", 
					RMIServer.REGISTRY_HOST, RMIServer.REGISTRY_PORT, bindingName);
			try {
				QueueOperate operator = (QueueOperate) Naming.lookup(lookUpUrl);
				Random randomGenerator = new Random();
				while(true){
					if(randomGenerator.nextDouble() < 0.5){
						// Fetch
						QueueItem item = operator.poll();
						if(item == null){
							log("Queue Empty");
						}else{
							log("Fetch Item " + item.id);
						}
					}else{
						// Put
						QueueItem newItem = new QueueItem(randomGenerator.nextInt(10000));
						log("Put Item " + newItem.id);
						operator.put(newItem);
					}
				}
			} catch (MalformedURLException | RemoteException
					| NotBoundException e) {
				e.printStackTrace();
			}
			
		}
	}
	
	public static void main(String[] args){
		
		int threadNumber = 10;
		for(int i = 0; i < threadNumber; i++){
			new ClientThread(i).start();
		}
		
		
	}
}
