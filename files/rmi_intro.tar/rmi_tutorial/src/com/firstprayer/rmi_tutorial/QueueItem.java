package com.firstprayer.rmi_tutorial;

import java.io.Serializable;

public class QueueItem implements Serializable {
	int id;
	public QueueItem(int i){
		id = i;
	}
}
