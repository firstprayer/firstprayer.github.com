package com.firstprayer.rmi_tutorial;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.LinkedList;
import java.util.Queue;

public class QueueOperateImpl extends UnicastRemoteObject implements QueueOperate{

	Queue<QueueItem> queue;
	protected QueueOperateImpl() throws RemoteException {
		super();
		queue = new LinkedList<QueueItem>();
	}

	@Override
	public synchronized void put(QueueItem item) throws RemoteException {
		queue.add(item);
	}

	@Override
	public synchronized QueueItem poll() throws RemoteException {
		return queue.poll();
	}

	@Override
	public synchronized int size() throws RemoteException {
		return queue.size();
	}

}
